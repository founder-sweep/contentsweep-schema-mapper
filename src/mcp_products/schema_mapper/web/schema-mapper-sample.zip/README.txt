Schema Mapper reviewed artifact

Install the free contentsweep-schema-mapper 2.0.0b2 runtime wheel (Python 3.12+).
The generated Python imports the matching runtime; it is not self-contained.
Keep mapping.approved.json. Reuse for this user/vendor/domain is free.
Structural/format changes require review; matching names/types cannot establish business meaning.
This bundle contains schema/decisions and validation counts, not raw source/output rows.
Engine: schema-mapper/2.0.0

FREE SYNTHETIC SAMPLE — no payment or customer data.
Create vendor.csv with these exact UTF-8 contents:

customer_id,first_name,credit_limit
000401,Ada,123456789012.123456789
000402,Grace,2500.05

Install the free matching runtime wheel with python -m pip install PATH_TO_WHEEL.
Then run from the extracted directory:
schema-map transform mapping.approved.json vendor.csv --user synthetic-sample --vendor "Synthetic example" --domain "Customer imports" --out output.jsonl --receipt run-receipt.json
The first output identifier remains 000401 and its amount remains exactly 123456789012.123456789.
